It can be difficult to figure out what's going wrong while integrating the transcoder into WebGL apps. To help debug using the transcoder, we've added development error messages throughout the entire module. This is done using the `BASISU_DEVEL_ERROR` macro. 

By default, these warning/error messages are disabled. To enable them set the `BASISU_FORCE_DEVEL_MESSAGES` macro to 1 when compiling `basisu_transcoder.cpp`, either by modifying `basisu_transcoder.h` or by specifying this macro on the compiler's command line.

Development messages will be sent to stdout, and appear in your browser's development console.
