We gratefully acknowledge the [Sponsors and Supporters](https://github.com/BinomialLLC/basis_universal/wiki/Sponsors-and-Supporters) of this software. Without their help, this project would not exist.

Unless otherwise explicitly indicated, all documents here are Copyright © 2016–2026 Binomial LLC. All rights reserved except as granted under the [Apache 2.0 license](https://github.com/BinomialLLC/basis_universal/blob/master/LICENSE). 

Here are the [Release Notes](Release-Notes).

## Legal
- [LICENSE](https://github.com/BinomialLLC/basis_universal/wiki/LICENSE) - The LICENSE covering our source code, specs and wiki documents (unless otherwise indicated). The source code LICENSE file (also Apache 2.0) is in the main repo [here](https://github.com/BinomialLLC/basis_universal/blob/master/LICENSE).
- [NOTICE](https://github.com/BinomialLLC/basis_universal/wiki/NOTICE) - Our NOTICE file, provided in accordance with the Apache License, Version 2.0 (§4(d))
- Other [Legal/IP/License Information](Legal-IP-License-Information) - GPU Texture Formats, Zstd, etc.

## Conceptual Architecture: GPU Textures are Infrastructure

- [The Three Generations of GPU Texture Distribution](The-Three-Generations-of-GPU-Texture-Distribution)
- [GPU Textures as Derived (Compiled) Data](GPU-Textures-as-Derived-(Compiled)-Data) - A conceptual model for modern texture distribution based on shader compilation principles
- [Basis Universal: Textures as Universal Latents](https://github.com/BinomialLLC/basis_universal/wiki/Basis-Universal:-Textures-as-Universal-Latents)
- [JPEG for ASTC](https://github.com/BinomialLLC/basis_universal/wiki/JPEG-for-ASTC) - Part of the XUASTC LDR specification

## Codec Bitstream Specifications

### Non-Copyrighted (Public Domain/CC0) Open Specifications

- [Basis File Format and ETC1S Texture/Texture Video Specification](.basis-File-Format-and-ETC1S-Texture-Video-Specification)
- [UASTC LDR 4x4 Texture Specification](UASTC-LDR-4x4-Texture-Specification)

### Copyrighted (Apache 2.0) Open Specifications
- [XUASTC LDR Specification](https://github.com/BinomialLLC/basis_universal/wiki/XUASTC-LDR)
- [UASTC HDR 4x4 Texture Specification](UASTC-HDR-4x4-Texture-Specification)
- [UASTC HDR 6x6 Intermediate Texture Specification](https://github.com/BinomialLLC/basis_universal/wiki/UASTC-HDR-6x6-Intermediate-File-Format-(Basis-GPU-Photo-6x6))
- [KTX2 File Format Support Technical Details](KTX2-File-Format-Support-Technical-Details) - Documents how we utilize the KTX2 file format (header ID's, DFD info, key-value fields etc.)

## Codec Specific Articles

- [ASTC and XUASTC LDR Usage Guide](https://github.com/BinomialLLC/basis_universal/wiki/ASTC-and-XUASTC-LDR-Usage-Guide)
- [UASTC LDR 4x4 Implementation Details](https://github.com/BinomialLLC/basis_universal/wiki/UASTC-LDR-4x4-implementation-details)
- [ASTC HDR 6x6 and UASTC HDR 6x6i Support Notes](https://github.com/BinomialLLC/basis_universal/wiki/UASTC-HDR-6x6-Support-Notes)

## References, Notes, Articles

- [Project Policies](https://github.com/BinomialLLC/basis_universal/wiki/Project-Policies:-PR's,-compiler-warnings,-release-cadence,-etc.)
- [How to Use and Configure the Transcoder](How-to-Use-and-Configure-the-Transcoder)
- [How to Deploy ETC1S Texture Content Using Basis Universal](How-to-Deploy-ETC1S-Texture-Content-Using-Basis-Universal)
- [Transcoder Texture Format Support for ETC1S and UASTC LDR 4x4](Transcoder-Texture-Format-Support-for-ETC1S-and-UASTC-LDR-4x4)
- A [table](OpenGL-texture-format-enums-table) showing which OpenGL texture format corresponds to each supported transcoder texture format.
- [ETC1S Compression Effort Levels](ETC1S-Compression-Effort-Levels)
- [ETC1S Encoder Speed](ETC1S-Encoder-Speed)
- [Transcoder Debugging](Transcoder-Debugging)
- [Encoding ETC1S and XUASTC LDR Texture Video](Encoding-ETC1S-and-XUASTC-LDR-Texture-Video)
- [Displaying .astc file block statistics using the `-peek` command line option](Displaying-.astc-file-block-statistics-using-the-peek-command-line-option)
- [ASTC Decoding: Software Decoders, Spec Issues, and ARM Errata](List-of-Available-Software-ASTC-Decoders)

## Encoder and Transcoding Pure C API Documentation
The library and transcoder module is written in C++, but we do support a plain C-API that exposes all key functionality. The C API is [FFI-friendly](https://grokipedia.com/page/Foreign_function_interface) and also designed for WASM use (i.e. when the encoder library or transcoder is compiled as a WASM WASI module). This is the API we use for native Python and in our WASI WASM modules, but it's also callable from any language that supports plain C API's. Also see the [pure C API example](https://github.com/BinomialLLC/basis_universal/tree/master/example_capi).

- [C API: Common Definitions](Pure-C-API-Common-Definitions)
- [C API: Compression](Pure-C-API-Compression)
- [C API: Transcoding](Pure-C-API-Transcoding)

## C++ API Documentation
The C++ API offers direct access to all compressor functionality in the encoder library and the single .cpp source file transcoder module.

- [Compressor Definitions and Classes](Compressor-Definitions-and-Classes)
- [Transcoder Module Definitions and Classes](Transcoder-Module-Definitions-and-Classes)
- [Transcoder Internals: Analytical Real-time Encoders](https://github.com/BinomialLLC/basis_universal/wiki/Transcoder-Internals-Analytical-Real-Time-Encoders) - These internal real-time GPU texture block encoders are available for use by developers for advanced use cases

## Python Support

Python support is layered on top of our C API, which is documented above. We support calling this API from Python either via the libraries compiled as WASM WASI modules (single threaded only, so compression is slow, but transcoding is fast), or via native .so or .pyd files (which internally supports multithreaded compression). We've so far tested Python support under Windows and Ubuntu Linux with Python v3.12.3. More info is [here](https://github.com/BinomialLLC/basis_universal/tree/master/python), or see the [Windows build instructions](https://github.com/BinomialLLC/basis_universal/blob/master/python/README_win.md). The module first tries to load native .so's or .pyd's, and if this fails it'll try falling back to our WASM WASI modules via the [wasmtime package](https://pypi.org/project/wasmtime/). The native code's C API is completely made available to Python using [pybind11](https://github.com/pybind/pybind11).

The higher level Python API's are not stable yet (we are new to Python), but the lower level C API it depends on is quite stable. Several low-level tests, higher-level LDR/HDR compression and transcoding tests, and a simple example [explode_ktx2 command line tool](https://github.com/BinomialLLC/basis_universal/blob/master/python/explode_ktx2_file.py) written entirely in Python are in the [python](https://github.com/BinomialLLC/basis_universal/tree/master/python) directory. 

## Examples

- [Python+OpenGL Pixel Shader Deblocking Sample](https://github.com/BinomialLLC/basis_universal/tree/master/shader_deblocking) - It's easy to greatly reduce block artifacts from large block size ASTC textures by using a special pixel shader to sample the texture. The shader detects when it's going to sample near a block border (which is entirely predictable and easy to determine) and applies a small horizontal and/or vertical filter across only block boundaries. This shader is compatible with mipmapping, bilinear and trilinear filtering, and anisotropic filtering, and any ASTC block size.
- [Pure C API example](https://github.com/BinomialLLC/basis_universal/tree/master/example_capi) - Written in C, shows how to use our plain C API.
- [WebGL examples](https://github.com/BinomialLLC/basis_universal/tree/master/webgl) - Also see our [Javascript emscripten API wrappers](https://github.com/BinomialLLC/basis_universal/blob/master/webgl/transcoder/basis_wrappers.cpp), which are layered on top of the C++ API.
- [C++ Transcoding Example](https://github.com/BinomialLLC/basis_universal/tree/master/example_transcoding)
- [C++ Compression/Transcoding Example](https://github.com/BinomialLLC/basis_universal/tree/master/example)
- [Python Examples](https://github.com/BinomialLLC/basis_universal/tree/master/python)

## File Format Related References
- [.basis File Format Overview](.basis-file-format-overview)
- [.basis File Format Forward/Backward Compatibility](.basis-Format-Forwards-and-Backwards-Compatibility)

## Misc. Documents
- [Using Basis Universal to decompress any supported GPU texture format](Using-Basis-Universal-to-decompress-any-supported-GPU-texture-format)
- [How to benchmark or directly call the UASTC LDR 4x4 functions without using .basis](How-to-benchmark-or-directly-call-the-UASTC-functions-without-using-.basis)

## See Also
- [KTX-Software-Binomial-Fork](https://github.com/BinomialLLC/KTX-Software-Binomial-Fork) - `btx` command line tool, used for validation and interoperability testing of .KTX2 container files containing Basis Universal codec data.
