*ASTC: No Longer a Black Box*

The `basisu` command line tool has a new option, `-peek`, which opens any standard ARM LDR/HDR [.ASTC texture file](https://github.com/ARM-software/astc-encoder/blob/main/Docs/FileFormat.md), unpacks each block, and computes a bunch of statistics about the exact ASTC configurations the blocks used. It outputs the unique list of ASTC block mode configurations used. Additionally, it unpacks the texture data to .png and .exr files.

We have some enhancements to this option coming in the v2.1 release. Examples below.

## UASTC HDR 4x4 example:

`-peek` command output on the .astc file:

```
Basis Universal LDR/HDR GPU Texture Supercompression System v2.00.0 (x64)
Copyright (C) 2019-2026 Binomial LLC, All rights reserved

Examining .astc file: "1_unpacked_ASTC_HDR_4X4_RGBA_face_0_layer_0000.astc"
Block dimensions in pixels: 4x4, 16 total pixels
Image dimensions in pixels: 644x876
Extra cols/rows to pad image to ASTC block dimensions: 0x0
Total LDR blocks: 0, total HDR blocks: 35259
Wrote astc_decoded_srgb8_ldr.png
Wrote astc_decoded_linear8_ldr.png
Wrote astc_decoded_half.exr

ASTC file statistics:
Total blocks: 35259, total void extent LDR: 0, total void extent HDR: 0, total normal: 35259
Total dual plane: 0 0.00%
Total subsets across all blocks: 39145, Avg. subsets per block: 1.110213
Min weight grid dimensions: 4x4
Max weight grid width: 4, height: 4

Partition usage histogram:
1: 31373 88.98%
2: 3886 11.02%
3: 0 0.00%
4: 0 0.00%

CEM usage histogram (percentages relative to total overall subsets used in texture):
0: 0 0.00%, total BC: 0 0.00%, total DP: 0 0.00%
1: 0 0.00%, total BC: 0 0.00%, total DP: 0 0.00%
2: 0 0.00%, total BC: 0 0.00%, total DP: 0 0.00%
3: 0 0.00%, total BC: 0 0.00%, total DP: 0 0.00%
4: 0 0.00%, total BC: 0 0.00%, total DP: 0 0.00%
5: 0 0.00%, total BC: 0 0.00%, total DP: 0 0.00%
6: 0 0.00%, total BC: 0 0.00%, total DP: 0 0.00%
7: 0 0.00%, total BC: 0 0.00%, total DP: 0 0.00%
8: 0 0.00%, total BC: 0 0.00%, total DP: 0 0.00%
9: 0 0.00%, total BC: 0 0.00%, total DP: 0 0.00%
10: 0 0.00%, total BC: 0 0.00%, total DP: 0 0.00%
11: 39145 100.00%, total BC: 0 0.00%, total DP: 0 0.00%
12: 0 0.00%, total BC: 0 0.00%, total DP: 0 0.00%
13: 0 0.00%, total BC: 0 0.00%, total DP: 0 0.00%
14: 0 0.00%, total BC: 0 0.00%, total DP: 0 0.00%

Used endpoint ISE levels:
6 levels: 0
8 levels: 0
10 levels: 0
12 levels: 0
16 levels: 0
20 levels: 0
24 levels: 0
32 levels: 0
40 levels: 3886
48 levels: 0
64 levels: 0
80 levels: 0
96 levels: 0
128 levels: 0
160 levels: 0
192 levels: 23960
256 levels: 7413

Used weight ISE levels:
2 levels: 0
3 levels: 0
4 levels: 3886
5 levels: 0
6 levels: 0
8 levels: 0
10 levels: 0
12 levels: 7413
16 levels: 23960
20 levels: 0
24 levels: 0
32 levels: 0

Total 2+ subset blocks using unequal CEM's: 0 0.00%
Total 2 subset blocks using unequal CEM's: 0 0.00%
Total 3 subset blocks using unequal CEM's: 0 0.00%
Total 4 subset blocks using unequal CEM's: 0 0.00%

Highest part ID seed: 828, 0x33c

Weight grid usage histogram:
  4x4: total blocks 35259

Total unique ASTC configurations: 3
  0. Used 7413 21.02% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 11 0 0 0, WeightISERange: 7, EndpointISERange: 20
  1. Used 23960 67.95% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 11 0 0 0, WeightISERange: 8, EndpointISERange: 19
  2. Used 3886 11.02% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 11 11 0 0, WeightISERange: 2, EndpointISERange: 12
Success
```

# XUASTC LDR 6x6 Example

Texture created with:

```
basisu D:\dev\test_images\bik\bik10.png -debug -xuastc_ldr_6x6 -quality 75 -xyd
basisu bik10.ktx2
basisu -peek bik10_unpacked_ASTC_LDR_6X6_RGBA_face_0_layer_0000.astc
```

`-peek` command output on the .astc file:

```
C:\dev\bu_2_13\basis_universal\bin>basisud -peek bik10_unpacked_ASTC_LDR_6X6_RGBA_face_0_layer_0000.astc
DEBUG or _DEBUG defined
NDEBUG is NOT defined
Basis Universal LDR/HDR GPU Texture Supercompression System v2.00.0 (x64)
Copyright (C) 2019-2026 Binomial LLC, All rights reserved

Examining .astc file: "bik10_unpacked_ASTC_LDR_6X6_RGBA_face_0_layer_0000.astc"
Block dimensions in pixels: 6x6, 36 total pixels
Image dimensions in pixels: 960x960
Extra cols/rows to pad image to ASTC block dimensions: 0x0
Total LDR blocks: 28766, total HDR blocks: 0
Wrote astc_decoded_srgb8_ldr.png
Wrote astc_decoded_linear8_ldr.png
Wrote astc_decoded_half.exr

ASTC file statistics:
Total blocks: 25600, total void extent LDR: 3166, total void extent HDR: 0, total normal: 22434
Total dual plane: 5338 20.85%
Total subsets across all blocks: 24598, Avg. subsets per block: 0.960859
Min weight grid dimensions: 2x2
Max weight grid width: 6, height: 6

Partition usage histogram:
1: 20542 80.24%
2: 1620 6.33%
3: 272 1.06%
4: 0 0.00%

CEM usage histogram (percentages relative to total overall subsets used in texture):
0: 413 1.68%, total BC: 0 0.00%, total DP: 0 0.00%
1: 0 0.00%, total BC: 0 0.00%, total DP: 0 0.00%
2: 0 0.00%, total BC: 0 0.00%, total DP: 0 0.00%
3: 0 0.00%, total BC: 0 0.00%, total DP: 0 0.00%
4: 0 0.00%, total BC: 0 0.00%, total DP: 0 0.00%
5: 0 0.00%, total BC: 0 0.00%, total DP: 0 0.00%
6: 3178 12.92%, total BC: 0 0.00%, total DP: 170 0.69%
7: 0 0.00%, total BC: 0 0.00%, total DP: 0 0.00%
8: 21007 85.40%, total BC: 13360 54.31%, total DP: 5168 21.01%
9: 0 0.00%, total BC: 0 0.00%, total DP: 0 0.00%
10: 0 0.00%, total BC: 0 0.00%, total DP: 0 0.00%
11: 0 0.00%, total BC: 0 0.00%, total DP: 0 0.00%
12: 0 0.00%, total BC: 0 0.00%, total DP: 0 0.00%
13: 0 0.00%, total BC: 0 0.00%, total DP: 0 0.00%
14: 0 0.00%, total BC: 0 0.00%, total DP: 0 0.00%

Used endpoint ISE levels:
6 levels: 12
8 levels: 61
10 levels: 161
12 levels: 124
16 levels: 385
20 levels: 579
24 levels: 387
32 levels: 986
40 levels: 411
48 levels: 106
64 levels: 1938
80 levels: 2786
96 levels: 705
128 levels: 1899
160 levels: 663
192 levels: 4973
256 levels: 6258

Used weight ISE levels:
2 levels: 0
3 levels: 694
4 levels: 1601
5 levels: 1181
6 levels: 4154
8 levels: 1738
10 levels: 1551
12 levels: 2941
16 levels: 1783
20 levels: 1271
24 levels: 1899
32 levels: 3621

Total 2+ subset blocks using unequal CEM's: 0 0.00%
Total 2 subset blocks using unequal CEM's: 0 0.00%
Total 3 subset blocks using unequal CEM's: 0 0.00%
Total 4 subset blocks using unequal CEM's: 0 0.00%

Highest part ID seed: 1022, 0x3fe

Weight grid usage histogram:
  4x2: total blocks 6
  5x2: total blocks 121
  6x2: total blocks 2366
  2x3: total blocks 1
  3x3: total blocks 181
  4x3: total blocks 208
  5x3: total blocks 1249
  6x3: total blocks 2596
  2x4: total blocks 65
  3x4: total blocks 291
  4x4: total blocks 821
  5x4: total blocks 761
  6x4: total blocks 859
  2x5: total blocks 224
  3x5: total blocks 1516
  4x5: total blocks 669
  5x5: total blocks 1209
  6x5: total blocks 425
  2x6: total blocks 3378
  3x6: total blocks 3748
  4x6: total blocks 860
  5x6: total blocks 498
  6x6: total blocks 382

Total unique ASTC configurations: 441
  0. Used 25 0.10% times: Solid LDR: false HDR: false, Grid: 2x4, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 11, EndpointISERange: 20
  1. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 6x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 3, EndpointISERange: 20
  2. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 4x6, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 1, EndpointISERange: 20
  3. Used 23 0.09% times: Solid LDR: false HDR: false, Grid: 3x4, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 19
  4. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 3, EndpointISERange: 5
  5. Used 11 0.04% times: Solid LDR: false HDR: false, Grid: 6x4, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 4, EndpointISERange: 5
  6. Used 1188 4.64% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 7, EndpointISERange: 19
  7. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 4x5, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 2, EndpointISERange: 10
  8. Used 14 0.05% times: Solid LDR: false HDR: false, Grid: 4x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 0 0 0 0, WeightISERange: 7, EndpointISERange: 20
  9. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 4, EndpointISERange: 6
  10. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 4x6, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 1, EndpointISERange: 20
  11. Used 9 0.04% times: Solid LDR: false HDR: false, Grid: 4x5, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 4, EndpointISERange: 7
  12. Used 73 0.29% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 11
  13. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 2x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 0 0 0 0, WeightISERange: 11, EndpointISERange: 20
  14. Used 6 0.02% times: Solid LDR: false HDR: false, Grid: 6x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 4, EndpointISERange: 8
  15. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 3, EndpointISERange: 20
  16. Used 10 0.04% times: Solid LDR: false HDR: false, Grid: 3x4, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 19
  17. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 6x2, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 8, EndpointISERange: 8
  18. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 1, EndpointISERange: 7
  19. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 6x4, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 1, EndpointISERange: 12
  20. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 5x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 5, EndpointISERange: 6
  21. Used 25 0.10% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 2, EndpointISERange: 14
  22. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 3, EndpointISERange: 13
  23. Used 14 0.05% times: Solid LDR: false HDR: false, Grid: 6x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 5, EndpointISERange: 11
  24. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 4, EndpointISERange: 14
  25. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 4x5, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 2, EndpointISERange: 17
  26. Used 107 0.42% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 3, EndpointISERange: 15
  27. Used 7 0.03% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 3, EndpointISERange: 20
  28. Used 81 0.32% times: Solid LDR: false HDR: false, Grid: 6x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 12
  29. Used 33 0.13% times: Solid LDR: false HDR: false, Grid: 4x5, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 3, EndpointISERange: 9
  30. Used 259 1.01% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 9, EndpointISERange: 20
  31. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 6x2, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 6, EndpointISERange: 10
  32. Used 195 0.76% times: Solid LDR: false HDR: false, Grid: 4x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 6, EndpointISERange: 18
  33. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 2x3, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 9, EndpointISERange: 14
  34. Used 53 0.21% times: Solid LDR: false HDR: false, Grid: 3x4, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 5, EndpointISERange: 14
  35. Used 72 0.28% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 1, EndpointISERange: 20
  36. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 3x4, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 2, EndpointISERange: 14
  37. Used 8 0.03% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 1, EndpointISERange: 8
  38. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 2, EndpointISERange: 11
  39. Used 606 2.37% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 8, EndpointISERange: 15
  40. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 4x5, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 2, EndpointISERange: 10
  41. Used 82 0.32% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 0 0 0 0, WeightISERange: 11, EndpointISERange: 20
  42. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 5x4, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 4, EndpointISERange: 4
  43. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 3x4, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 5, EndpointISERange: 20
  44. Used 78 0.30% times: Solid LDR: false HDR: false, Grid: 3x4, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 11, EndpointISERange: 20
  45. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 6, EndpointISERange: 7
  46. Used 54 0.21% times: Solid LDR: false HDR: false, Grid: 5x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 2, EndpointISERange: 20
  47. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 11, EndpointISERange: 11
  48. Used 41 0.16% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 11
  49. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 3, EndpointISERange: 8
  50. Used 30 0.12% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 4, EndpointISERange: 11
  51. Used 8 0.03% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 3, EndpointISERange: 8
  52. Used 6 0.02% times: Solid LDR: false HDR: false, Grid: 5x4, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 1, EndpointISERange: 18
  53. Used 20 0.08% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 2, EndpointISERange: 6
  54. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 4x6, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 1, EndpointISERange: 12
  55. Used 12 0.05% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 4, EndpointISERange: 19
  56. Used 110 0.43% times: Solid LDR: false HDR: false, Grid: 5x5, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 2, EndpointISERange: 8
  57. Used 7 0.03% times: Solid LDR: false HDR: false, Grid: 4x3, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 19
  58. Used 754 2.95% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 10, EndpointISERange: 17
  59. Used 8 0.03% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 5, EndpointISERange: 9
  60. Used 7 0.03% times: Solid LDR: false HDR: false, Grid: 6x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 5, EndpointISERange: 6
  61. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 5, EndpointISERange: 9
  62. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 3x3, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 9, EndpointISERange: 11
  63. Used 152 0.59% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 10, EndpointISERange: 14
  64. Used 260 1.02% times: Solid LDR: false HDR: false, Grid: 5x4, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 6, EndpointISERange: 18
  65. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 3x3, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 8, EndpointISERange: 14
  66. Used 7 0.03% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 4, EndpointISERange: 19
  67. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 4x6, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 1, EndpointISERange: 6
  68. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 2x5, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 8, EndpointISERange: 18
  69. Used 18 0.07% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 5, EndpointISERange: 7
  70. Used 7 0.03% times: Solid LDR: false HDR: false, Grid: 5x5, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 1, EndpointISERange: 10
  71. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 6x2, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 5, EndpointISERange: 20
  72. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 4x3, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 7, EndpointISERange: 9
  73. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 2x4, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 9, EndpointISERange: 15
  74. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 3, EndpointISERange: 5
  75. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 4x5, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 2, EndpointISERange: 10
  76. Used 69 0.27% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 3, EndpointISERange: 15
  77. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 3x4, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 4, EndpointISERange: 12
  78. Used 22 0.09% times: Solid LDR: false HDR: false, Grid: 4x3, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 5, EndpointISERange: 14
  79. Used 57 0.22% times: Solid LDR: false HDR: false, Grid: 5x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 12
  80. Used 41 0.16% times: Solid LDR: false HDR: false, Grid: 6x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 3, EndpointISERange: 16
  81. Used 12 0.05% times: Solid LDR: false HDR: false, Grid: 2x5, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 6, EndpointISERange: 17
  82. Used 43 0.17% times: Solid LDR: false HDR: false, Grid: 5x4, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 8, EndpointISERange: 11
  83. Used 45 0.18% times: Solid LDR: false HDR: false, Grid: 2x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 11, EndpointISERange: 20
  84. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 4, EndpointISERange: 15
  85. Used 15 0.06% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 10, EndpointISERange: 17
  86. Used 8 0.03% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 3, EndpointISERange: 17
  87. Used 9 0.04% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 5, EndpointISERange: 8
  88. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 3, EndpointISERange: 12
  89. Used 60 0.23% times: Solid LDR: false HDR: false, Grid: 3x4, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 5, EndpointISERange: 14
  90. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 5x6, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 1, EndpointISERange: 8
  91. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 2, EndpointISERange: 20
  92. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 2x5, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 4, EndpointISERange: 8
  93. Used 8 0.03% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 2, EndpointISERange: 11
  94. Used 288 1.12% times: Solid LDR: false HDR: false, Grid: 5x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 19
  95. Used 11 0.04% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 2, EndpointISERange: 14
  96. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 2, EndpointISERange: 20
  97. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 4x5, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 5, EndpointISERange: 5
  98. Used 19 0.07% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 6, EndpointISERange: 18
  99. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 6x2, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 10, EndpointISERange: 20
  100. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 3, EndpointISERange: 20
  101. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 4, EndpointISERange: 15
  102. Used 34 0.13% times: Solid LDR: false HDR: false, Grid: 5x2, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 6, EndpointISERange: 17
  103. Used 21 0.08% times: Solid LDR: false HDR: false, Grid: 6x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 2, EndpointISERange: 20
  104. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 11
  105. Used 53 0.21% times: Solid LDR: false HDR: false, Grid: 4x3, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 11, EndpointISERange: 20
  106. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 3, EndpointISERange: 14
  107. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 4x3, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 5, EndpointISERange: 20
  108. Used 6 0.02% times: Solid LDR: false HDR: false, Grid: 4x3, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 5, EndpointISERange: 11
  109. Used 15 0.06% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 2, EndpointISERange: 20
  110. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 5, EndpointISERange: 13
  111. Used 153 0.60% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 2, EndpointISERange: 14
  112. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 3, EndpointISERange: 7
  113. Used 45 0.18% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 11, EndpointISERange: 14
  114. Used 230 0.90% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 11, EndpointISERange: 20
  115. Used 28 0.11% times: Solid LDR: false HDR: false, Grid: 5x4, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 8, EndpointISERange: 19
  116. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 5x5, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 4, EndpointISERange: 8
  117. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 2x5, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 7, EndpointISERange: 11
  118. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 5, EndpointISERange: 19
  119. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 5x5, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 2, EndpointISERange: 8
  120. Used 51 0.20% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 2, EndpointISERange: 20
  121. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 2x4, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 10, EndpointISERange: 13
  122. Used 10 0.04% times: Solid LDR: false HDR: false, Grid: 5x4, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 4, EndpointISERange: 7
  123. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 6x2, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 9, EndpointISERange: 13
  124. Used 19 0.07% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 11, EndpointISERange: 20
  125. Used 13 0.05% times: Solid LDR: false HDR: false, Grid: 5x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 2, EndpointISERange: 10
  126. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 5x4, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 5, EndpointISERange: 10
  127. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 2x4, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 9, EndpointISERange: 15
  128. Used 106 0.41% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 5, EndpointISERange: 14
  129. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 6x2, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 2, EndpointISERange: 8
  130. Used 22 0.09% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 10, EndpointISERange: 17
  131. Used 27 0.11% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 5, EndpointISERange: 13
  132. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 4, EndpointISERange: 14
  133. Used 16 0.06% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 3, EndpointISERange: 15
  134. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 3, EndpointISERange: 14
  135. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 3, EndpointISERange: 20
  136. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 1, EndpointISERange: 7
  137. Used 12 0.05% times: Solid LDR: false HDR: false, Grid: 3x3, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 7, EndpointISERange: 18
  138. Used 12 0.05% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 4, EndpointISERange: 7
  139. Used 45 0.18% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 11, EndpointISERange: 20
  140. Used 56 0.22% times: Solid LDR: false HDR: false, Grid: 4x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 5, EndpointISERange: 20
  141. Used 233 0.91% times: Solid LDR: false HDR: false, Grid: 4x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 20
  142. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 3x3, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 8, EndpointISERange: 20
  143. Used 47 0.18% times: Solid LDR: false HDR: false, Grid: 6x2, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 11, EndpointISERange: 20
  144. Used 535 2.09% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 19
  145. Used 12 0.05% times: Solid LDR: false HDR: false, Grid: 4x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 7, EndpointISERange: 20
  146. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 9, EndpointISERange: 19
  147. Used 38 0.15% times: Solid LDR: false HDR: false, Grid: 5x5, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 3, EndpointISERange: 6
  148. Used 185 0.72% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 4, EndpointISERange: 9
  149. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 5, EndpointISERange: 15
  150. Used 24 0.09% times: Solid LDR: false HDR: false, Grid: 5x4, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 1, EndpointISERange: 18
  151. Used 68 0.27% times: Solid LDR: false HDR: false, Grid: 6x4, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 6, EndpointISERange: 19
  152. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 4x3, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 6, EndpointISERange: 17
  153. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 2x5, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 6, EndpointISERange: 12
  154. Used 52 0.20% times: Solid LDR: false HDR: false, Grid: 4x3, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 5, EndpointISERange: 14
  155. Used 12 0.05% times: Solid LDR: false HDR: false, Grid: 5x4, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 2, EndpointISERange: 10
  156. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 6x2, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 5, EndpointISERange: 20
  157. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 2x4, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 6, EndpointISERange: 14
  158. Used 8 0.03% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 10, EndpointISERange: 10
  159. Used 11 0.04% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 2, EndpointISERange: 20
  160. Used 23 0.09% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 4, EndpointISERange: 11
  161. Used 55 0.21% times: Solid LDR: false HDR: false, Grid: 2x5, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 6, EndpointISERange: 17
  162. Used 8 0.03% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 3, EndpointISERange: 13
  163. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 4x2, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 8, EndpointISERange: 18
  164. Used 1468 5.73% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 11, EndpointISERange: 20
  165. Used 155 0.61% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 1, EndpointISERange: 20
  166. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 6x2, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 4, EndpointISERange: 7
  167. Used 8 0.03% times: Solid LDR: false HDR: false, Grid: 6x4, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 3, EndpointISERange: 6
  168. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 8, EndpointISERange: 8
  169. Used 12 0.05% times: Solid LDR: false HDR: false, Grid: 2x4, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 8, EndpointISERange: 18
  170. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 3x3, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 9, EndpointISERange: 19
  171. Used 15 0.06% times: Solid LDR: false HDR: false, Grid: 6x5, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 2, EndpointISERange: 5
  172. Used 33 0.13% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 1, EndpointISERange: 20
  173. Used 58 0.23% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 6, EndpointISERange: 10
  174. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 4, EndpointISERange: 6
  175. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 5, EndpointISERange: 6
  176. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 3, EndpointISERange: 20
  177. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 5x5, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 1, EndpointISERange: 10
  178. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 5x4, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 2, EndpointISERange: 10
  179. Used 8 0.03% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 3, EndpointISERange: 11
  180. Used 133 0.52% times: Solid LDR: false HDR: false, Grid: 6x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 4, EndpointISERange: 20
  181. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 5x4, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 1, EndpointISERange: 18
  182. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 6x4, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 1, EndpointISERange: 12
  183. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 5x4, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 3, EndpointISERange: 9
  184. Used 11 0.04% times: Solid LDR: false HDR: false, Grid: 5x4, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 2, EndpointISERange: 10
  185. Used 56 0.22% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 1, EndpointISERange: 20
  186. Used 124 0.48% times: Solid LDR: false HDR: false, Grid: 5x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 4, EndpointISERange: 20
  187. Used 8 0.03% times: Solid LDR: false HDR: false, Grid: 4x5, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 1, EndpointISERange: 18
  188. Used 10 0.04% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 11
  189. Used 46 0.18% times: Solid LDR: false HDR: false, Grid: 5x4, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 3, EndpointISERange: 9
  190. Used 6 0.02% times: Solid LDR: false HDR: false, Grid: 5x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 0 0 0 0, WeightISERange: 7, EndpointISERange: 20
  191. Used 62 0.24% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 1, EndpointISERange: 20
  192. Used 34 0.13% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 2, EndpointISERange: 20
  193. Used 6 0.02% times: Solid LDR: false HDR: false, Grid: 6x2, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 5, EndpointISERange: 14
  194. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 10, EndpointISERange: 12
  195. Used 18 0.07% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 11, EndpointISERange: 19
  196. Used 20 0.08% times: Solid LDR: false HDR: false, Grid: 6x5, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 2, EndpointISERange: 10
  197. Used 63 0.25% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 5, EndpointISERange: 14
  198. Used 102 0.40% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 2, EndpointISERange: 14
  199. Used 8 0.03% times: Solid LDR: false HDR: false, Grid: 6x4, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 3, EndpointISERange: 12
  200. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 5x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 1, EndpointISERange: 15
  201. Used 920 3.59% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 7, EndpointISERange: 19
  202. Used 6 0.02% times: Solid LDR: false HDR: false, Grid: 4x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 4, EndpointISERange: 9
  203. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 3x4, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 7, EndpointISERange: 9
  204. Used 298 1.16% times: Solid LDR: false HDR: false, Grid: 6x2, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 19
  205. Used 75 0.29% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 3, EndpointISERange: 15
  206. Used 41 0.16% times: Solid LDR: false HDR: false, Grid: 4x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 8, EndpointISERange: 19
  207. Used 268 1.05% times: Solid LDR: false HDR: false, Grid: 4x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 7, EndpointISERange: 15
  208. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 4x5, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 2, EndpointISERange: 5
  209. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 3, EndpointISERange: 8
  210. Used 8 0.03% times: Solid LDR: false HDR: false, Grid: 3x3, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 8, EndpointISERange: 14
  211. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 9, EndpointISERange: 19
  212. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 0 0 0 0, WeightISERange: 7, EndpointISERange: 20
  213. Used 8 0.03% times: Solid LDR: false HDR: false, Grid: 5x5, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 1, EndpointISERange: 5
  214. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 8, EndpointISERange: 9
  215. Used 152 0.59% times: Solid LDR: false HDR: false, Grid: 6x4, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 5, EndpointISERange: 15
  216. Used 63 0.25% times: Solid LDR: false HDR: false, Grid: 2x5, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 6, EndpointISERange: 17
  217. Used 24 0.09% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 6, EndpointISERange: 8
  218. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 1, EndpointISERange: 13
  219. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 6, EndpointISERange: 5
  220. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 6, EndpointISERange: 17
  221. Used 10 0.04% times: Solid LDR: false HDR: false, Grid: 5x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 2, EndpointISERange: 5
  222. Used 26 0.10% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 4, EndpointISERange: 12
  223. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 6x2, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 3, EndpointISERange: 7
  224. Used 109 0.43% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 9, EndpointISERange: 12
  225. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 4, EndpointISERange: 10
  226. Used 103 0.40% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 4, EndpointISERange: 9
  227. Used 25 0.10% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 11
  228. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 3x4, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 6, EndpointISERange: 10
  229. Used 6 0.02% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 5, EndpointISERange: 14
  230. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 5x5, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 1, EndpointISERange: 10
  231. Used 18 0.07% times: Solid LDR: false HDR: false, Grid: 4x3, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 19
  232. Used 124 0.48% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 19
  233. Used 14 0.05% times: Solid LDR: false HDR: false, Grid: 4x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 0 0 0 0, WeightISERange: 10, EndpointISERange: 20
  234. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 6x4, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 1, EndpointISERange: 11
  235. Used 298 1.16% times: Solid LDR: false HDR: false, Grid: 6x4, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 20
  236. Used 26 0.10% times: Solid LDR: false HDR: false, Grid: 5x5, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 3, EndpointISERange: 11
  237. Used 44 0.17% times: Solid LDR: false HDR: false, Grid: 3x3, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 7, EndpointISERange: 18
  238. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 2, EndpointISERange: 18
  239. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 3, EndpointISERange: 12
  240. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 5x5, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 2, EndpointISERange: 4
  241. Used 39 0.15% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 2, EndpointISERange: 14
  242. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 6x6, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 1, EndpointISERange: 6
  243. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 6x4, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 2, EndpointISERange: 8
  244. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 5x5, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 1, EndpointISERange: 10
  245. Used 16 0.06% times: Solid LDR: false HDR: false, Grid: 6x2, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 5, EndpointISERange: 11
  246. Used 24 0.09% times: Solid LDR: false HDR: false, Grid: 4x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 2, EndpointISERange: 8
  247. Used 21 0.08% times: Solid LDR: false HDR: false, Grid: 5x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 0 0 0 0, WeightISERange: 5, EndpointISERange: 20
  248. Used 62 0.24% times: Solid LDR: false HDR: false, Grid: 4x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 8, EndpointISERange: 11
  249. Used 51 0.20% times: Solid LDR: false HDR: false, Grid: 3x3, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 7, EndpointISERange: 18
  250. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 2x5, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 10, EndpointISERange: 9
  251. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 3, EndpointISERange: 20
  252. Used 33 0.13% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 3, EndpointISERange: 10
  253. Used 888 3.47% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 10, EndpointISERange: 17
  254. Used 7 0.03% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 3, EndpointISERange: 8
  255. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 5x6, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 1, EndpointISERange: 4
  256. Used 17 0.07% times: Solid LDR: false HDR: false, Grid: 4x3, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 6, EndpointISERange: 10
  257. Used 9 0.04% times: Solid LDR: false HDR: false, Grid: 5x2, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 7, EndpointISERange: 14
  258. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 3x4, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 6, EndpointISERange: 17
  259. Used 31 0.12% times: Solid LDR: false HDR: false, Grid: 6x2, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 5, EndpointISERange: 14
  260. Used 16 0.06% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 10, EndpointISERange: 20
  261. Used 114 0.45% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 0 0 0 0, WeightISERange: 11, EndpointISERange: 20
  262. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 6x2, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 6, EndpointISERange: 18
  263. Used 11 0.04% times: Solid LDR: false HDR: false, Grid: 6x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 1, EndpointISERange: 20
  264. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 4x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 4, EndpointISERange: 5
  265. Used 89 0.35% times: Solid LDR: false HDR: false, Grid: 6x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 3, EndpointISERange: 16
  266. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 6x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 0 0 0 0, WeightISERange: 2, EndpointISERange: 16
  267. Used 6 0.02% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 8, EndpointISERange: 15
  268. Used 11 0.04% times: Solid LDR: false HDR: false, Grid: 6x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 1, EndpointISERange: 6
  269. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 2, EndpointISERange: 19
  270. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 6x2, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 5, EndpointISERange: 11
  271. Used 8 0.03% times: Solid LDR: false HDR: false, Grid: 2x4, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 9, EndpointISERange: 15
  272. Used 10 0.04% times: Solid LDR: false HDR: false, Grid: 5x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 3, EndpointISERange: 7
  273. Used 72 0.28% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 9, EndpointISERange: 12
  274. Used 17 0.07% times: Solid LDR: false HDR: false, Grid: 5x5, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 2, EndpointISERange: 14
  275. Used 194 0.76% times: Solid LDR: false HDR: false, Grid: 4x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 6, EndpointISERange: 11
  276. Used 156 0.61% times: Solid LDR: false HDR: false, Grid: 6x2, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 19
  277. Used 10 0.04% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 4, EndpointISERange: 9
  278. Used 71 0.28% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 11, EndpointISERange: 14
  279. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 5x2, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 5, EndpointISERange: 13
  280. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 3, EndpointISERange: 12
  281. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 6x5, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 1, EndpointISERange: 15
  282. Used 6 0.02% times: Solid LDR: false HDR: false, Grid: 2x4, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 8, EndpointISERange: 18
  283. Used 16 0.06% times: Solid LDR: false HDR: false, Grid: 5x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 5, EndpointISERange: 11
  284. Used 32 0.12% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 3, EndpointISERange: 13
  285. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 5x4, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 2, EndpointISERange: 17
  286. Used 16 0.06% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 3, EndpointISERange: 15
  287. Used 124 0.48% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 5, EndpointISERange: 11
  288. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 6x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 0 0 0 0, WeightISERange: 5, EndpointISERange: 20
  289. Used 208 0.81% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 2, EndpointISERange: 14
  290. Used 154 0.60% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 8, EndpointISERange: 19
  291. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 6x2, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 6, EndpointISERange: 10
  292. Used 23 0.09% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 10, EndpointISERange: 20
  293. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 5x5, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 1, EndpointISERange: 17
  294. Used 7 0.03% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 3, EndpointISERange: 8
  295. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 6x4, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 1, EndpointISERange: 6
  296. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 5x4, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 0 0 0 0, WeightISERange: 10, EndpointISERange: 20
  297. Used 46 0.18% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 2, EndpointISERange: 20
  298. Used 342 1.34% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 9, EndpointISERange: 16
  299. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 2x4, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 6, EndpointISERange: 8
  300. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 4x3, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 6, EndpointISERange: 17
  301. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 2, EndpointISERange: 7
  302. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 6x4, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 2, EndpointISERange: 15
  303. Used 49 0.19% times: Solid LDR: false HDR: false, Grid: 3x3, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 8, EndpointISERange: 14
  304. Used 6 0.02% times: Solid LDR: false HDR: false, Grid: 3x4, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 6, EndpointISERange: 10
  305. Used 18 0.07% times: Solid LDR: false HDR: false, Grid: 6x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 2, EndpointISERange: 6
  306. Used 6 0.02% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 3, EndpointISERange: 10
  307. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 3x3, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 11, EndpointISERange: 20
  308. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 6x5, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 1, EndpointISERange: 8
  309. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 8
  310. Used 752 2.94% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 8, EndpointISERange: 15
  311. Used 17 0.07% times: Solid LDR: false HDR: false, Grid: 6x4, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 2, EndpointISERange: 8
  312. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 2x4, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 6, EndpointISERange: 14
  313. Used 22 0.09% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 5, EndpointISERange: 7
  314. Used 16 0.06% times: Solid LDR: false HDR: false, Grid: 2x5, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 7, EndpointISERange: 14
  315. Used 9 0.04% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 3, EndpointISERange: 10
  316. Used 21 0.08% times: Solid LDR: false HDR: false, Grid: 3x4, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 6, EndpointISERange: 10
  317. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 4, EndpointISERange: 19
  318. Used 9 0.04% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 2, EndpointISERange: 20
  319. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 2, EndpointISERange: 20
  320. Used 3166 12.37% times: Solid LDR: true HDR: false, Grid: 0x0, Dual Plane: false, CCS: 0, NumParts: 0, CEMS: 0 0 0 0, WeightISERange: 0, EndpointISERange: 0
  321. Used 34 0.13% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 11
  322. Used 17 0.07% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 3, EndpointISERange: 13
  323. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 5x5, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 1, EndpointISERange: 17
  324. Used 63 0.25% times: Solid LDR: false HDR: false, Grid: 5x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 6, EndpointISERange: 16
  325. Used 20 0.08% times: Solid LDR: false HDR: false, Grid: 4x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 3, EndpointISERange: 12
  326. Used 13 0.05% times: Solid LDR: false HDR: false, Grid: 6x4, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 7, EndpointISERange: 14
  327. Used 8 0.03% times: Solid LDR: false HDR: false, Grid: 6x2, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 5, EndpointISERange: 20
  328. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 3, EndpointISERange: 6
  329. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 2x4, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 8, EndpointISERange: 18
  330. Used 13 0.05% times: Solid LDR: false HDR: false, Grid: 5x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 1, EndpointISERange: 8
  331. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 6x4, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 5, EndpointISERange: 6
  332. Used 17 0.07% times: Solid LDR: false HDR: false, Grid: 6x5, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 1, EndpointISERange: 8
  333. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 6, EndpointISERange: 17
  334. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 5x4, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 9, EndpointISERange: 14
  335. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 4, EndpointISERange: 11
  336. Used 9 0.04% times: Solid LDR: false HDR: false, Grid: 5x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 7, EndpointISERange: 11
  337. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 3x4, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 5, EndpointISERange: 20
  338. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 5, EndpointISERange: 20
  339. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 4, EndpointISERange: 9
  340. Used 34 0.13% times: Solid LDR: false HDR: false, Grid: 6x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 0 0 0 0, WeightISERange: 4, EndpointISERange: 20
  341. Used 7 0.03% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 6, EndpointISERange: 10
  342. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 4x5, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 3, EndpointISERange: 9
  343. Used 148 0.58% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 2, EndpointISERange: 14
  344. Used 10 0.04% times: Solid LDR: false HDR: false, Grid: 4x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 7, EndpointISERange: 14
  345. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 5, EndpointISERange: 20
  346. Used 62 0.24% times: Solid LDR: false HDR: false, Grid: 4x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 6, EndpointISERange: 19
  347. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 6x5, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 1, EndpointISERange: 4
  348. Used 122 0.48% times: Solid LDR: false HDR: false, Grid: 5x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 5, EndpointISERange: 20
  349. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 5x2, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 7, EndpointISERange: 14
  350. Used 445 1.74% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 9, EndpointISERange: 20
  351. Used 14 0.05% times: Solid LDR: false HDR: false, Grid: 6x4, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 0 0 0 0, WeightISERange: 7, EndpointISERange: 20
  352. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 5x2, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 6, EndpointISERange: 12
  353. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 3, EndpointISERange: 17
  354. Used 21 0.08% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 2, EndpointISERange: 20
  355. Used 536 2.09% times: Solid LDR: false HDR: false, Grid: 6x2, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 19
  356. Used 14 0.05% times: Solid LDR: false HDR: false, Grid: 6x5, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 3, EndpointISERange: 7
  357. Used 10 0.04% times: Solid LDR: false HDR: false, Grid: 6x2, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 6, EndpointISERange: 10
  358. Used 137 0.54% times: Solid LDR: false HDR: false, Grid: 6x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 2, EndpointISERange: 15
  359. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 4, EndpointISERange: 11
  360. Used 8 0.03% times: Solid LDR: false HDR: false, Grid: 5x4, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 7, EndpointISERange: 20
  361. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 4x5, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 2, EndpointISERange: 10
  362. Used 11 0.04% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 2, EndpointISERange: 6
  363. Used 7 0.03% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 4, EndpointISERange: 19
  364. Used 13 0.05% times: Solid LDR: false HDR: false, Grid: 6x4, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 7, EndpointISERange: 8
  365. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 4x2, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 9, EndpointISERange: 15
  366. Used 6 0.02% times: Solid LDR: false HDR: false, Grid: 5x2, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 7, EndpointISERange: 14
  367. Used 6 0.02% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 2, EndpointISERange: 20
  368. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 7, EndpointISERange: 9
  369. Used 8 0.03% times: Solid LDR: false HDR: false, Grid: 6x2, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 7, EndpointISERange: 9
  370. Used 24 0.09% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 2, EndpointISERange: 8
  371. Used 58 0.23% times: Solid LDR: false HDR: false, Grid: 6x4, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 5, EndpointISERange: 20
  372. Used 7 0.03% times: Solid LDR: false HDR: false, Grid: 2x5, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 5, EndpointISERange: 13
  373. Used 108 0.42% times: Solid LDR: false HDR: false, Grid: 5x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 6, EndpointISERange: 9
  374. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 3, EndpointISERange: 14
  375. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 5x4, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 2, EndpointISERange: 17
  376. Used 16 0.06% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 5, EndpointISERange: 9
  377. Used 18 0.07% times: Solid LDR: false HDR: false, Grid: 4x3, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 19
  378. Used 29 0.11% times: Solid LDR: false HDR: false, Grid: 6x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 3, EndpointISERange: 9
  379. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 0 0 0 0, WeightISERange: 11, EndpointISERange: 20
  380. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 0 0 0 0, WeightISERange: 11, EndpointISERange: 20
  381. Used 6 0.02% times: Solid LDR: false HDR: false, Grid: 4x6, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 1, EndpointISERange: 12
  382. Used 372 1.45% times: Solid LDR: false HDR: false, Grid: 5x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 5, EndpointISERange: 14
  383. Used 65 0.25% times: Solid LDR: false HDR: false, Grid: 6x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 2, EndpointISERange: 20
  384. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 5x4, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 2, EndpointISERange: 10
  385. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 5x2, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 6, EndpointISERange: 17
  386. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 5x4, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 1, EndpointISERange: 7
  387. Used 6 0.02% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 2, EndpointISERange: 11
  388. Used 53 0.21% times: Solid LDR: false HDR: false, Grid: 6x2, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 0 0 0 0, WeightISERange: 11, EndpointISERange: 20
  389. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 2, EndpointISERange: 7
  390. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 8
  391. Used 286 1.12% times: Solid LDR: false HDR: false, Grid: 5x4, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 7, EndpointISERange: 15
  392. Used 1132 4.42% times: Solid LDR: false HDR: false, Grid: 6x2, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 11, EndpointISERange: 20
  393. Used 27 0.11% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 2, EndpointISERange: 20
  394. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 6x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 4
  395. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 7, EndpointISERange: 13
  396. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 4x6, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 2, EndpointISERange: 4
  397. Used 18 0.07% times: Solid LDR: false HDR: false, Grid: 3x4, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 19
  398. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 2, EndpointISERange: 7
  399. Used 11 0.04% times: Solid LDR: false HDR: false, Grid: 6x4, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 4, EndpointISERange: 9
  400. Used 7 0.03% times: Solid LDR: false HDR: false, Grid: 4x6, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 1, EndpointISERange: 11
  401. Used 64 0.25% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 3, EndpointISERange: 10
  402. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 3, EndpointISERange: 8
  403. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 4x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 2, EndpointISERange: 15
  404. Used 10 0.04% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 6, EndpointISERange: 10
  405. Used 69 0.27% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 1, EndpointISERange: 20
  406. Used 42 0.16% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 0 0 0 0, WeightISERange: 11, EndpointISERange: 20
  407. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 6x3, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 7, EndpointISERange: 8
  408. Used 14 0.05% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 4, EndpointISERange: 10
  409. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 6x4, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 1, EndpointISERange: 12
  410. Used 9 0.04% times: Solid LDR: false HDR: false, Grid: 5x5, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 1, EndpointISERange: 10
  411. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 6x2, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 4, EndpointISERange: 12
  412. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 4x6, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 2, EndpointISERange: 8
  413. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 2, EndpointISERange: 18
  414. Used 419 1.64% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 19
  415. Used 79 0.31% times: Solid LDR: false HDR: false, Grid: 3x5, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 3, EndpointISERange: 15
  416. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 6x4, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 3, EndpointISERange: 6
  417. Used 169 0.66% times: Solid LDR: false HDR: false, Grid: 5x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 3, EndpointISERange: 16
  418. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 4x5, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 6 6 6 0, WeightISERange: 2, EndpointISERange: 10
  419. Used 25 0.10% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 6, EndpointISERange: 8
  420. Used 184 0.72% times: Solid LDR: false HDR: false, Grid: 4x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 5, EndpointISERange: 15
  421. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 7, EndpointISERange: 7
  422. Used 10 0.04% times: Solid LDR: false HDR: false, Grid: 2x5, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 7, EndpointISERange: 14
  423. Used 21 0.08% times: Solid LDR: false HDR: false, Grid: 6x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 1, EndpointISERange: 11
  424. Used 12 0.05% times: Solid LDR: false HDR: false, Grid: 4x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 3, EndpointISERange: 6
  425. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 4x5, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 9, EndpointISERange: 14
  426. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 4x3, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 5, EndpointISERange: 14
  427. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 3x4, Dual Plane: true, CCS: 1, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 5, EndpointISERange: 14
  428. Used 1 0.00% times: Solid LDR: false HDR: false, Grid: 2x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 8 8 0 0, WeightISERange: 2, EndpointISERange: 14
  429. Used 20 0.08% times: Solid LDR: false HDR: false, Grid: 5x2, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 6, EndpointISERange: 17
  430. Used 166 0.65% times: Solid LDR: false HDR: false, Grid: 6x4, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 6, EndpointISERange: 11
  431. Used 4 0.02% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 6 0 0 0, WeightISERange: 3, EndpointISERange: 14
  432. Used 10 0.04% times: Solid LDR: false HDR: false, Grid: 4x4, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 4, EndpointISERange: 8
  433. Used 8 0.03% times: Solid LDR: false HDR: false, Grid: 3x6, Dual Plane: false, CCS: 0, NumParts: 2, CEMS: 6 6 0 0, WeightISERange: 6, EndpointISERange: 10
  434. Used 30 0.12% times: Solid LDR: false HDR: false, Grid: 6x2, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 5, EndpointISERange: 14
  435. Used 2 0.01% times: Solid LDR: false HDR: false, Grid: 5x3, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 1, EndpointISERange: 8
  436. Used 38 0.15% times: Solid LDR: false HDR: false, Grid: 5x2, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 11, EndpointISERange: 20
  437. Used 7 0.03% times: Solid LDR: false HDR: false, Grid: 4x6, Dual Plane: false, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 7, EndpointISERange: 8
  438. Used 6 0.02% times: Solid LDR: false HDR: false, Grid: 5x2, Dual Plane: false, CCS: 0, NumParts: 3, CEMS: 8 8 8 0, WeightISERange: 4, EndpointISERange: 8
  439. Used 5 0.02% times: Solid LDR: false HDR: false, Grid: 4x5, Dual Plane: true, CCS: 0, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 1, EndpointISERange: 18
  440. Used 3 0.01% times: Solid LDR: false HDR: false, Grid: 3x3, Dual Plane: true, CCS: 2, NumParts: 1, CEMS: 8 0 0 0, WeightISERange: 9, EndpointISERange: 11
Success
```
