# XUASTC LDR v1.1
Copyright (C) 2025-2026 Binomial LLC. All rights reserved except as granted under the [Apache 2.0 LICENSE](https://github.com/BinomialLLC/basis_universal/blob/master/LICENSE). Also see our [NOTICE file](https://github.com/BinomialLLC/basis_universal/wiki/NOTICE). If you modify the Basis Universal source code, specifications, or wiki documents and redistribute the files, you must cause any modified files to carry prominent notices stating that you changed the files (see Apache 2.0 §4(b)).

# Intro: Moving JPEG Up a Level

XUASTC LDR is a DCT transform-based analysis-by-synthesis (AbS) texture and image codec built entirely on existing GPU hardware texture decoding capabilities, operating by compressing images or textures into a compact, [ASTC](https://grokipedia.com/page/Adaptive_scalable_texture_compression)-aligned (unlearned) structured latent representation defined by the ASTC reconstruction model, which is entropy-coded and later transcoded to GPU texture formats. 

**XUASTC LDR ports and relocates the transform-codec abstraction that JPEG uses "upward" in the stack into ASTC, the most deployed GPU texture format in the world.** Put differently, XUASTC LDR is a transform-based supercompressed texture codec that operates directly in the ASTC decoder’s configuration space, which supports direct transcoding to BC7, or fast recompression to nearly all other LDR texture formats, with optional adaptive deblocking.

XUASTC LDR did not begin as an attempt to replicate JPEG. It emerged organically from solving a practical problem: how to compress ASTC blocks as efficiently as possible while preserving full hardware compatibility. But when the format is viewed as a whole, a deeper pattern becomes clear - one that mirrors the architecture of the most successful block-based image codec ever deployed.

As the author, having implemented [multiple JPEG encoders and decoders](https://github.com/richgel999/picojpeg) since the early 1990s on a variety of platforms (Motorola 6809, PIC 18F microcontrollers, 80386/486 DOS systems, etc.), the realization came only while writing this specification: XUASTC is essentially JPEG applied to ASTC’s internal image model. The transform–predict–quantize pipeline that JPEG applies to pixel blocks maps almost perfectly onto ASTC blocks when viewed through the right lens. ASTC endpoints function as per-block decorrelation transforms; endpoint DPCM provides cross-block DC prediction; ASTC interpolation weights form a sort of miniature quantized grayscale image; and a DCT-II/DCT-III pair, combined with an adaptively scaled JPEG quant table, performs transform coding on that image.

In effect, XUASTC moves JPEG “up a level” in the graphics pipeline. **Instead of compressing raw RGB pixel blocks, it compresses the structures that generate those pixels - ASTC endpoints, partitions, and weight grids.** (Essentially an unlearned "latent" representation.) These structures are already highly correlated and spatially coherent, making them an ideal substrate for JPEG’s decades-proven strategies. The result is a supercompressed ASTC intermediate format that feels natural, because it is built from the same principles that made JPEG so enduringly successful.

This perspective is not merely philosophical; it explains why XUASTC works as well as it does. ASTC’s internal representation behaves like a low-resolution, per-block image signal - exactly the kind of signal that JPEG’s machinery is designed to exploit. Compressing this signal directly yields the efficiency of a transform codec while retaining full compatibility with billions of hardware ASTC decoders already deployed worldwide.

In hindsight, this alignment seems obvious. But the insight only becomes visible after viewing ASTC not as a compression format to be mimicked, but as an implicit image domain ripe for transform coding. XUASTC LDR is the product of that realization.

* [ASTC and XUASTC LDR Usage Guide](https://github.com/BinomialLLC/basis_universal/wiki/ASTC-and-XUASTC-LDR-Usage-Guide#all-astcxuastc-related-command-line-options)
* [JPEG for ASTC (or what XUASTC LDR is, from a JPEG perspective)](https://github.com/BinomialLLC/basis_universal/wiki/JPEG-for-ASTC)
* [The Three Generations of GPU Texture Distribution](The-Three-Generations-of-GPU-Texture-Distribution)
* [XUASTC LDR - Specification](https://github.com/BinomialLLC/basis_universal/wiki/XUASTC-LDR-Specification-v1.0)
* [XUASTC LDR - Arithmetic Profile](https://github.com/BinomialLLC/basis_universal/wiki/XUASTC-LDR-Arithmetic-Profile)
* [XUASTC LDR - Endpoint Conversion for DPCM Prediction](https://github.com/BinomialLLC/basis_universal/wiki/XUASTC-LDR-Endpoint-Conversion-for-DPCM-Prediction)
* [XUASTC LDR - Weight Grid DCT](https://github.com/BinomialLLC/basis_universal/wiki/XUASTC-LDR-Weight-Grid-DCT)
* [XUASTC LDR - Arithmetic/Range Coding](https://github.com/BinomialLLC/basis_universal/wiki/XUASTC-LDR-Range-Coding)
* [XUASTC LDR - Logical ASTC Block Structure](https://github.com/BinomialLLC/basis_universal/wiki/XUASTC-LDR-log_astc_block-Structure)

