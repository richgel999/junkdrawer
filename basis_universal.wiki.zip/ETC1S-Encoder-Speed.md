### ETC1S Encoder Speed

Note: This content was composed before the ETC1S encoder was optimized in v1.13. The encoder is now significantly faster, by a factor of 2-3x or higher.

Total time for basisu.exe to compress a 1024x1024 ETC1S texture on a 7 year old 4-core 2.2GHz Core i7 laptop - timings are "without mipmaps/with mipmaps":

* -comp_level 0: 

-q 128: 2.2/3.5 secs

-q 255: 1.5/2.5 secs

* -comp_level 1:

-q 128: 4.1/6.2 secs

-q 255: 6.4/9.4 secs
