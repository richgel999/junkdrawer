### GPU texture format support details

*Note: This content was written before the ASTC LDR 4x4-12x12 and XUASTC LDR 4x4-12x12 codec formats were added to the system. These other formats are significantly higher quality than ETC1S/UASTC LDR 4x4.*

Here's a [table](https://github.com/BinomialLLC/basis_universal/wiki/OpenGL-texture-format-enums-table) showing the supported compressed texture formats and their corresponding OpenGL texture formats.

Internally, all ETC1S/UASTC LDR 4x4 format slice textures can be converted to any GPU texture format. The system supports all known LDR GPU texture formats, including obscure ones like FXT1/ATC. The transcoder's API supports converting alpha slices to color texture formats, which allows the user to transcode textures with alpha to two ETC1 images, etc.

**ETC1** - The system's internal texture format is ETC1S (for ETC1S format files), which is a pure subset of the ETC1 texture format, so outputting ETC1 texture data is trivial (it's a no-op). We only use differential encodings, each subblock uses the same base color (the differential color is always [0,0,0]), and flips are always enabled.

**ETC2** - The color block will be ETC1S, and the alpha block is EAC. Conversion from ETC1S->EAC is very fast and nearly lossless.

**BC1/DXT1** - ETC1S->BC1 conversion loses approx. .3-.5 dB Y PSNR relative to the source ETC1S data. We don't currently use 3 color (punchthrough) blocks, but we could easily add them. Conversion to BC1 uses several small lookup tables, so it's quite fast.

**BC3/DXT5** - The color block is BC1, the alpha block is BC4. ETC1S->BC4 is nearly lossless and very fast.

**BC4/DXT5A** - ETC1S->BC4 conversion is nearly lossless and very fast.

**BC5/3DC/DXN** - Two BC4 blocks. As the conversion from ETC1S->BC4 blocks is nearly lossless, we think this format (with large codebooks) will work well with high quality tangent space normal maps. Each channel gets its own ETC1S texture. Transcoding is very fast.

**BC7** - There are two transcoders, one for mode 6 RGB, and another for mode 5 RGB/RGBA. The conversion from ETC1S->BC7 mode 6 is nearly lossless, but the tables are very large. It is highly recommended you disable BC7 entirely (BASISD_SUPPORT_BC7=0) or disable the mode 6 transcoder (BASISD_SUPPORT_BC7_MODE6_OPAQUE_ONLY=0) at compilation time on platforms (like WebAssembly) where the compiled transcoder size matters.

Transcoding to BC7 mode 5 is very fast, mode 6 is slightly slower.

**Basis Universal v1.6 or later now supports ETC1S block chroma artifact filtering** specifically when transcoding to BC7. This actually makes BC7 a useful transcode target vs. BC1 or BC3 for ETC1S source content, but it does slow down transcoding. This behavior can be disabled by using the `cDecodeFlagsNoETC1SChromaFiltering` transcoder (decode) flag (see `enum basisu_decode_flags` in `transcoder/basisu_transcoder.h`).

**PVRTC1 4bpp** - There are two transcoders, one for RGB and another for RGBA. The conversion from ETC1S->PVRTC1 RGB is a two step process. The first step finds the RGB bounding boxes of each ETC1S block, which is fast (we don't need to process the entire block's pixels, just the 1-4 used block colors). The first pass occurs during ETC1S transcoding. The second pass computes the per-pixel 2-bpp modulation values, which is fast because we can do this in a luma-like colorspace using simple scalar (not full RGB) operations. The second pass is highly optimized, and threading it would be easy. Quality is roughly the same as PVRTexTool's "Normal (Good Quality)" setting. ETC1S->PVRTC1 loses the most quality - several Y dB PSNR. 

ETC1S->PVRTC1 RGBA is a three step process: first we unpack the ETC1S RGB slice, then the ETC1S A slice to a temp buffer, then we pack this data to PVRTC1 RGBA. The real-time transcoder is really only intended for relatively simple alpha channels, like opacity masks. If the output is too decorrelated or too complex opaque quality really suffers. We know how to improve PVRTC1 quality, but it would require another pass through the texture which would slow things down.

Interestingly, the low pass filtering-like artifacts due to PVRTC1's unique block endpoint interpolation help obscure ETC1S chroma artifacts. 

Currently, the PVRTC1 transcoder requires that the ETC1S texture's dimensions both be a power of two (but non-square is OK, although I believe iOS doesn't support that). We will be adding the ability to transcode non-pow2 ETC1S textures to larger pow2 PVRTC1 textures soon.

Note that for PVRTC1, the transcoder differs slightly in how it computes the memory size of compressed textures. Basis only writes (or requires) the output buffer to be total_blocks * bytes_per_block. But OpenGL requires extra padding for very small textures:

    // https://www.khronos.org/registry/OpenGL/extensions/IMG/IMG_texture_compression_pvrtc.txt
    const uint32_t width = (orig_width + 3) & ~3;
    const uint32_t height = (orig_height + 3) & ~3;
    const uint32_t size_in_bytes = (std::max(8U, width) * std::max(8U, height) * 4 + 7) / 8;
       
When you call the transcoder and pass it a buffer that's larger than required, these extra padding bytes will be set to 0.

**PVRTC2 RGB** - Fast and almost as high quality as BC1. It supports non-square, non-power of 2 textures.

**PVRTC2 RGBA** - This format is slower and much more complex than PVRTC2 RGB. It will only work well with textures using premultiplied alpha. The alpha channel should be relatively simple (like opacity maps).

**ETC2 EAC R11/RG11** - R11 is roughly equivalent to BC4, and RG11 is like BC5. Transcoding is very fast and high quality.

**ASTC 4x4** - The ASTC transcoder supports void extent (constant color) blocks and several different endpoint precision modes and encodings: L, LA, RGB or RGBA. To shrink the compiled size of the ASTC transcoder, set BASISD_SUPPORT_ASTC_HIGHER_OPAQUE_QUALITY to 0, which lowers endpoint precision slightly.

Note the ASTC transcoder assumes sRGB sampling won't be enabled when sampling the ASTC texture data. (ASTC decompression works slightly differently when sRGB reads are enabled vs. disabled.) Enabling sRGB reads will result in a tiny amount of higher error that is unlikely to be noticeable. This was a conscious decision we had to make because we could only afford to include one set of precomputed ETC1S->ASTC conversion tables into the transcoder. We may put in two tables into the next transcoder release and let the user decide what they want at compile and/or run-time.

**ATI ATC** - There are two transcoders, one for RGB (which is similar to BC1), and one for RGBA_INTERPOLATED_ALPHA (which is basically a BC4 block followed by an ATC block). This format is only useful on Adreno GPU's, so to cut down on the transcoder's size you can set BASISD_SUPPORT_ATC to 0 at compilation time if you know you'll never need ATC data. Quality is very similar to BC1/BC3.

**RGB565, BGR564, ARGB 8888 and ARGB 4444** - Various uncompressed raw pixel formats. Internally the transcoder directly converts the ETC1S endpoint/selector data directly to uncompressed pixels. The output buffer is treated as a plain raster image, not as a 2D array of blocks. No dithering or downsampling is supported yet.