This page shows a few .EXR/.PNG images compressed to .KTX2 ASTC 6x6 HDR or ASTC 6x6 HDR intermediate, using the Basis Universal ASTC HDR 6x6 codec, at various settings. Some images were compressed to plain ASTC HDR 6x6 (3.56 bpp), and some to our custom intermediate format which rapidly transcodes to ASTC HDR 6x6.

LDR/SDR inputs were upconverted to HDR by first converting each pixel from [sRGB](https://en.wikipedia.org/wiki/SRGB) to linear light RGB, then multiplying by a luminance of [100 nits](https://en.wikipedia.org/wiki/Candela_per_square_metre) (typical SDR monitors range from 80-100 nits).

For easy viewing on the web, the HDR images are [tone mapped](https://en.wikipedia.org/wiki/Tone_mapping) using a simple per-component global Reinhard tone mapping operator at various exposures. The tone mapped result was converted to 8-bit sRGB with no dithering.

Note: Example images used in this wiki are the property of their respective copyright holders and are used here under the doctrine of Fair Use for illustrative, research and educational purposes in a non-commercial, open source context.

--------

- Original tree.exr, 928x906, Reinhard tone mapped, log2 exposure scale=1:  
![image](https://github.com/user-attachments/assets/b3634f7b-3ecf-40b6-b726-bbc0a619485c)

- ASTC 6x6 HDR intermediate, Reinhard tone mapped, log2 exposure scale=1:  
.KTX2 file size: 315,877, 3.01 bits/pixel  
Command line: `basisu -lambda 3000 -hdr_6x6i_level 8 -debug_images -stats -debug C:\dev\lightprobe\Tree.exr`  
![image](https://github.com/user-attachments/assets/309f59a9-aabf-4a55-a4c7-bddc5e77ccb6)

- ASTC 6x6 HDR intermediate, Reinhard tone mapped, log2 exposure scale=-2:  
![image](https://github.com/user-attachments/assets/58f3db79-d663-4135-81db-3c50a261a8a8)

- ASTC 6x6 HDR intermediate, Reinhard tone mapped, log2 exposure scale=4:  
![image](https://github.com/user-attachments/assets/6e90f8e2-7b48-4412-b152-550c149c6e2d)

- ASTC 6x6 HDR intermediate, Reinhard tone mapped, log2 exposure scale=6:  
![image](https://github.com/user-attachments/assets/921b9e38-29f8-433c-a751-90257222a3d3)

- BC6H, Reinhard tone mapped, log2 exposure scale=1:  
![image](https://github.com/user-attachments/assets/1e465bf4-8421-4814-8ae7-1397a1bf2183)

--------

- Original desk.exr, 644x874, Reinhard tone mapped:  
![image](https://github.com/user-attachments/assets/4c8e878a-4082-4ac6-b191-e8c5c0628e30)

- ASTC 6x6 HDR (3.56 bits/pixel):  
Command line: `basisu -hdr_6x6_level 8 C:\dev\lightprobe\desk.exr -stats`  
![image](https://github.com/user-attachments/assets/66184ff9-0b49-4517-a75d-604ede2466b8)

- BC6H (8 bits/pixel):  
![image](https://github.com/user-attachments/assets/17e944dc-56ab-4ad3-a2f6-b826404fd41e)

--------

- Original BarHarborSunrise.exr, resampled to 3216x1809, Reinhard tone mapped:  
![image](https://github.com/user-attachments/assets/0cf0ecf3-c09a-470d-bb88-4b15891149d1)

- ASTC 6x6 HDR (3.56 bits/pixel):  
Command line: `basisu -hdr_6x6_level 8 C:\dev\lightprobe\BarHarborSunrise.exr -resample_factor .75 -stats -debug_images`  
![image](https://github.com/user-attachments/assets/3a4a5cd3-3b8e-4496-aabe-16b185bc9269)

- BC6H (8 bits/pixel)  
![image](https://github.com/user-attachments/assets/96673e5a-2561-42aa-8cce-8d80a70202ea)

--------

- Original CandleGlass.exr, 1000x810, Reinhard tone mapped, log2 exposure scale=2:  
![image](https://github.com/user-attachments/assets/09b991e9-931e-4b9d-ad82-1f843c0bfc67)

- ASTC 6x6 HDR (3.56 bits/pixel), log2 exposure scale=2:  
Command line: `basisu -hdr_6x6_level 8 C:\dev\lightprobe\CandleGlass.exr -stats -debug_images`  
![image](https://github.com/user-attachments/assets/eb97df28-d52c-4cfd-a3c3-2d6620bb73ff)

- BC6H (8 bits/pixel), log2 exposure scale=2:  
![image](https://github.com/user-attachments/assets/257189a7-1ce9-4390-a9f1-baabcf460ec8)

- ASTC 6x6 HDR (3.56 bits/pixel), log2 exposure scale=-8:
![image](https://github.com/user-attachments/assets/7d8ad396-b4cc-4c1b-b57c-5911880a1422)

- ASTC 6x6 HDR (3.56 bits/pixel), log2 exposure scale=8:  
![image](https://github.com/user-attachments/assets/e3b6b931-14a2-4723-9e28-c804c5e07aa4)

--------

- Original .PNG, 2000x1334:
![image](https://github.com/user-attachments/assets/5dcf5975-f616-4ed5-a10f-89a2e4ceb45c)

- Upconverted to linear light (100 nits), compressed to ASTC 6x6 intermediate .KTX2, uncompressed to ASTC 6x6 HDR, decoded and converted back to sRGB:  
.KTX2 file size: 697,456 bytes, 2.09 bits/pixel  
Command line: `basisu -lambda 5000 -hdr_6x6i_level 5 C:\dev\test_images\cnn-election-night3.png`  
![image](https://github.com/user-attachments/assets/593bcd0c-b9fe-4432-b56a-d740ef3c131c)

- BC6H:  
![image](https://github.com/user-attachments/assets/c5b68d11-346f-4ba1-bfda-58dcb560dd38)

--------

- Original starwars_768.png, 768x768:  
![image](https://github.com/user-attachments/assets/06bc1d5c-021f-4088-ba4b-15a811583ddc)

- Upconverted to linear light (100 nits), compressed to ASTC 6x6 intermediate .KTX2, uncompressed to ASTC 6x6 HDR, decoded and converted back to sRGB:  
.KTX2 file size: 191,228 bytes, 2.59 bits/pixel  
Command line: `basisu -lambda 5000 -hdr_6x6i_level 1 -debug_images -stats C:\dev\test_images\starwars_768.png`
![image](https://github.com/user-attachments/assets/5df2ed65-6802-42f6-ac79-0c8195188f99)

- BC6H:  
![image](https://github.com/user-attachments/assets/c86b280c-0e50-4299-901f-cf9dbe4740f3)

--------

- Original chief_768.png, 768x384:  
![image](https://github.com/user-attachments/assets/b9ba9b7a-2ed5-4e1a-88b3-4d72ecdf3665)

- Upconverted to linear light (100 nits), compressed to ASTC 6x6 intermediate .KTX2, uncompressed to ASTC 6x6 HDR, decoded and converted back to sRGB:  
.KTX2 file size: 102,657 bytes, 2.78 bits/pixel  
Command line: `basisu -lambda 5000 -hdr_6x6i_level 5 -debug_images -stats C:\dev\test_images\chief_768.png -debug`  
![image](https://github.com/user-attachments/assets/02d942c9-f519-4e30-b4de-0a65f436ceea)

- BC6H (8 bits/pixel):  
![image](https://github.com/user-attachments/assets/3881f1df-3647-4d22-99bf-b08a2a74a4d3)

- ASTC 6x6 HDR intermediate:  
.KTX2 file size: 87,930 bytes, 2.39 bits/pixel  
Command line: `basisu -lambda 20000 -hdr_6x6i_level 5 -debug_images -stats C:\dev\test_images\chief_768.png -debug`  
![image](https://github.com/user-attachments/assets/1d44507f-48c9-4f13-9f5b-109c0c719202)

- ASTC 6x6 HDR intermediate:  
.KTX2 file size: 68,217 bytes, 1.85 bits/pixel  
![image](https://github.com/user-attachments/assets/c104d52a-6ad2-479d-b7bb-82cdb038bbb0)

- ASTC 6x6 HDR intermediate:  
.KTX2 file size: 64,677 bytes, 1.75 bits/pixel  
![image](https://github.com/user-attachments/assets/ea1efdd4-81d3-4045-b8fe-d2f991e5d58f)

--------

- Original rain_1k.png, 1024x685  
![image](https://github.com/user-attachments/assets/e015b725-fb9a-4b54-8ff9-614d10442855)

- Upconverted to linear light (100 nits), compressed to ASTC 6x6 HDR .KTX2, decoded and converted back to sRGB:  
Command line: `basisu -hdr_6x6_level 8 -debug_images -stats -debug C:\dev\test_images\rain_1k.png`  
![image](https://github.com/user-attachments/assets/fcee5168-0363-4c02-bf68-8eba91d95628)

- BC6H (8 bits/pixel)  
![image](https://github.com/user-attachments/assets/e33f4581-06c7-40f7-8e1e-304aeb762004)

- ASTC 6x6 HDR intermediate  
.KTX2 file size: 228,856 bytes, 2.61 bits/pixel  
Command line: `basisu -lambda 10000 -hdr_6x6i_level 8 -debug_images -stats -debug C:\dev\test_images\rain_1k.png`  
![image](https://github.com/user-attachments/assets/2a523fde-90d8-4cde-8d4b-cdf584e7b290)

- ASTC 6x6 HDR intermediate  
.KTX2 file size: 200,972 bytes, 2.29 bits/pixel  
Command line: `basisu -lambda 30000 -hdr_6x6i_level 8 -debug_images -stats -debug C:\dev\test_images\rain_1k.png`  
![image](https://github.com/user-attachments/assets/d703a59d-54d0-4fdd-a4d6-af3b8222825b)

--------

- Original tng.png, 700x999  
![image](https://github.com/user-attachments/assets/0b0fdafe-2542-4bf2-ae12-b11a9bb1dc77)

- ASTC HDR 6x6 (3.56 bits/pixel)  
.KTX2 file size: 299,392 3.43 bits/pixel  
Command line: `basisu -hdr_6x6_level 8 -debug_images -stats -debug C:\dev\test_images\tng.png`  
![image](https://github.com/user-attachments/assets/32eb1621-e8b6-4b08-98ea-8b8e66f25346)

- BC6H (8 bits/pixel)  
![image](https://github.com/user-attachments/assets/ca9ef142-4bdc-4fe3-bb4a-4851efb83488)

