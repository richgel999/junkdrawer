*Note: This content was written before the ASTC LDR 4x4-12x12 and XUASTC LDR 4x4-12x12 codecs were added to the system. This table needs to be updated, as we now support transcoding all 14 ASTC block sizes from these two codec formats.*

Here's a table of OpenGL texture formats/internal formats enums corresponding to each compressed texture format in the `transcoder_texture_format` enum in [transcoder/basisu_transcoder.h](https://github.com/BinomialLLC/basis_universal/blob/master/transcoder/basisu_transcoder.h). The command line tool uses these OpenGL enums when it writes .KTX format texture files. 

The transcoder supports all of these GPU texture formats, and the encoder library has code to decompress all of these formats.

| transcoder_texture_format | GL internal format        | GL base internal format  |
| :------------------------ | :-----------------------------: | -----------------: |
| cTFBC1_RGB|GL_COMPRESSED_RGB_S3TC_DXT1_EXT|GL_RGB|
| cTFBC3_RGBA|GL_COMPRESSED_RGBA_S3TC_DXT5_EXT|GL_RGBA|
| cTFBC4_R|GL_COMPRESSED_RED_RGTC1_EXT|GL_RED|
|cTFBC5_RG|GL_COMPRESSED_RED_GREEN_RGTC2_EXT|GL_RG|
|cTFETC1_RGB|GL_ETC1_RGB8_OES|GL_RGB|
|cTFETC2_RGBA|GL_COMPRESSED_RGBA8_ETC2_EAC|GL_RGBA|
|cTFBC7_RGBA|GL_COMPRESSED_RGBA_BPTC_UNORM|GL_RGBA|
|cTFPVRTC1_4_RGB|GL_COMPRESSED_RGB_PVRTC_4BPPV1_IMG|GL_RGB|
|cTFPVRTC1_4_RGBA|GL_COMPRESSED_RGBA_PVRTC_4BPPV1_IMG|GL_RGBA|
|cTFASTC_4x4_RGBA|GL_COMPRESSED_RGBA_ASTC_4x4_KHR|GL_RGBA|
|cTFATC_RGB|GL_ATC_RGB_AMD|GL_RGB|
|cTFATC_RGBA|GL_ATC_RGBA_INTERPOLATED_ALPHA_AMD|GL_RGBA|
|cTFETC2_EAC_R11|GL_COMPRESSED_R11_EAC|GL_RED|
|cTFETC2_EAC_RG11|GL_COMPRESSED_RG11_EAC|GL_RG|
|cTFFXT1_RGB|GL_COMPRESSED_RGB_FXT1_3DFX|GL_RGB|
|cTFPVRTC2_4_RGB, cTFPVRTC2_4_RGBA|GL_COMPRESSED_RGBA_PVRTC_4BPPV2_IMG|GL_RGBA|
