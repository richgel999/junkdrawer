A huge thanks to Google for partnering with us and enabling this system to be open sourced and sponsoring additional codecs. Another huge thank you to [Esri](https://www.esri.com/en-us/home) (Environmental Systems Research Institute) for sponsoring the encoder optimization work in the v1.13 release, the KTX2 work in the v1.15 release, and OpenCL support in the v1.16 release.

Thanks to the Khronos Group and its developers for building an open ecosystem that supports ETC1S/UASTC. In particular thanks to [Mark Callow](https://github.com/MarkCallow) at Edgewise Consulting for his work on glTF and the KTX2 file format at Khronos.

Thanks to a number of companies or groups who have supported or helped out Binomial over the years: Intel, SpaceX, Netflix, Forgotten Empires, Microsoft, Polystream, Hothead Games, BioDigital, Magic Leap, Blizzard Entertainment, Insomniac Games, Rockstar Games, Facebook, Activision, the Khronos Group, and the organizers at CppCon.

Thanks to Dave Wilkinson (AMD/Khronos) for supporting us and giving us very valuable feedback while we developed Basis Universal.

Thanks to Chris Wein (Netflix), who showed us the path to Texture Video.

Thanks to Mike Dussault (SpaceX) and Elon Musk for supporting Binomial in the early days.

Thanks to Graeme Devine at Magic Leap for helping things along.

Thanks to Matt Pritchard, formerly of Valve Software and Microsoft, for helping me with the computer hardware I used while building this system and its predecessor.

Thanks to John Brooks at Blue Shift, Inc. for inspiring this work by showing me his Dreamcast texture compression system around 2002, and for releasing etc2comp. I first saw the subblock flip estimation approach (used in basisu_etc.cpp) in etc2comp.

Thanks to Colt McAnlis, for advertising one of my earlier open source texture compression libraries at GDC, and Won Chun, who originally suggested making a universal system.

Thanks to Chas Boyd (Microsoft), for inspiring us to work on texture compression full-time. Chas also gave us great feedback about UASTC before it was released.


