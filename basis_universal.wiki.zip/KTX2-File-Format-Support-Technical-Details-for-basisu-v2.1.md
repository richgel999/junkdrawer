See [here](https://github.com/BinomialLLC/basis_universal/wiki/KTX2-File-Format-Support-Technical-Details).
