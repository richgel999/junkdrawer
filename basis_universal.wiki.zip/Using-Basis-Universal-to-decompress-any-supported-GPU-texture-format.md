The Basis Universal encoder/transcoder libraries contain easy to use functions to unpack the following standard compressed GPU texture formats:

## Full support:
- ASTC - Full specification, any block size, LDR/HDR, all standard ASTC decode profiles (linear vs. sRGB etc.), 9E5 support, logical and physical block packing and unpacking, CEM decoding, BISE quant/dequant, optimized partition pattern subset index calculation, faster XUASTC LDR-only block decoding, fuzzed, two full low-level decoders (for correctness checking): See the stand-alone header library [`transcoder/basisu_astc_helpers.h`](https://github.com/BinomialLLC/basis_universal/blob/master/transcoder/basisu_astc_helpers.h) or [`encoder/3rdparty/android_astc_decomp.h`](https://github.com/BinomialLLC/basis_universal/blob/master/encoder/3rdparty/android_astc_decomp.h). Fuzz compared vs. ARM's decoder in astcenc.
- BC7 - Fully specification, in transcoder .cpp module, see `transcoder/basisu_transcoder_internal.h`, low-level function `basist::bc7u::unpack_bc7()`.
- BC6H - Full specification (signed or unsigned variant), in encoder library.
- BC1-5 - Full format
- ETC1 - Full format
- ETC2 EAC R11/RG11 - Only unpacks to 8-bit/channel
- PVRTC1 4bpp RGB/RGBA - Decompression has been verified against PVRTexTool's output for correctness.
- ATC RGB/RGBA

## Limited support (just what we encode to):
- ETC2 RGB/RGBA8 - Only supports ETC1 for color data (no planar, T/H modes). EAC alpha data is fully supported
- PVRTC2 - Limited support: Just the non-interpolated mode our transcoders use.
- FXT1 - Limited support: just the specific BC1-like mode we use

Before you can unpack textures, be sure to call `basisu_encoder_init()` once at startup.

To unpack individual 4x4 (or 8x4 for FXT1) texel blocks to raw RGBA pixels, use one of these functions declared in `encoder/basisu_gpu_texture.h`:

```
bool unpack_block(texture_format fmt, const void *pBlock, color_rgba *pPixels, bool astc_srgb);
bool unpack_block_hdr(texture_format fmt, const void* pBlock, vec4F* pPixels);
```

This doesn't work on PVRTC1 textures, because the decoder needs access to the surrounding blocks. Alternately, you can create a `basisu::gpu_image` object, then call `gpu_image::unpack()` or `gpu_image::unpack_hdr()`. This works on any supported format, including PVRTC1. 

