*Note: this page was generated using a very early version of the HDR 6x6 codec and is now obsolete.*

Reinhard tonemapped, Core i7 (Raptor Lake). Features: 48 ASTC HDR 6x6 modes, 1 or 2 subsets, weight grid upsampling, CEM 7/11, [ICtCp colorspace](https://en.wikipedia.org/wiki/ICtCp) error metrics, Lagrangian Rate-Distortion Optimization with perceptual weighting, endpoint DPCM, ASTC configuration reuse.

Notes:
- The LDR examples below were converted from sRGB to linear light and then multiplied by 100 nits before encoding as HDR.
- These images are already outdated - we've added dual plane support to the encoder. Roughly 1/3-1/2 of blocks now use dual planes.

------

- candleglass.exr, 1000x810, 1.36 bits/pixel, 4.4ms decode to ASTC, 27.7ms transcode to BC6H

[ASTC HDR 6x6](https://github.com/user-attachments/assets/cf5832c1-03d8-437d-8047-3a4054e2797a)  
![image](https://github.com/user-attachments/assets/cf5832c1-03d8-437d-8047-3a4054e2797a)

[BC6H](https://github.com/user-attachments/assets/762d15a2-21e8-41e5-b4b5-7c2eae0bd775)  
![image](https://github.com/user-attachments/assets/762d15a2-21e8-41e5-b4b5-7c2eae0bd775)

[ASTC HDR 6x6](https://github.com/user-attachments/assets/20369647-e78a-4d58-9ce6-b9d8a491db82)  
![image](https://github.com/user-attachments/assets/20369647-e78a-4d58-9ce6-b9d8a491db82)

[BC6H](https://github.com/user-attachments/assets/f230cfa4-7f27-4a95-a91b-fcff3a904af4)  
![image](https://github.com/user-attachments/assets/f230cfa4-7f27-4a95-a91b-fcff3a904af4)

- office.hdr, 2000x1312, 2.39 bits/pixel, 39ms decode to ASTC, 12.5ms transcode to BC6H

[ASTC HDR 6x6](https://github.com/user-attachments/assets/21dec01c-590a-4ed8-8f47-a878d4988d51):  
![image](https://github.com/user-attachments/assets/21dec01c-590a-4ed8-8f47-a878d4988d51)

[BC6H](https://github.com/user-attachments/assets/680faf4f-76d7-4a9c-9992-b3186843b398):  
![image](https://github.com/user-attachments/assets/680faf4f-76d7-4a9c-9992-b3186843b398)

[ASTC HDR 6x6](https://github.com/user-attachments/assets/248bd75f-50d4-40a4-9d5c-943787b64b22):  
![image](https://github.com/user-attachments/assets/248bd75f-50d4-40a4-9d5c-943787b64b22)

[BC6H](https://github.com/user-attachments/assets/fd630df6-3208-45c8-8990-dc4d133ae397):  
![image](https://github.com/user-attachments/assets/fd630df6-3208-45c8-8990-dc4d133ae397)

- aft_lounge_4k.exr, 4096x2048, 2.28 bits/pixel, 55ms decode to ASTC, 370ms transcode to BC6H 

[ASTC HDR 6x6](https://github.com/richgel999/junkdrawer/blob/main/aft_lounge_4k_astc_6x6_exp_1_6.png):  
![ASTC 6x6](https://github.com/richgel999/junkdrawer/blob/main/aft_lounge_4k_astc_6x6_exp_1_6.png)

[BC6H](https://github.com/richgel999/junkdrawer/blob/main/aft_lounge_4k_bc6h_exp_1_6.png):  
![BC6H](https://github.com/richgel999/junkdrawer/blob/main/aft_lounge_4k_bc6h_exp_1_6.png)

[ASTC HDR 6x6](https://github.com/richgel999/junkdrawer/blob/main/aft_lounge_4k_astc_6x6_exp_3_0.png):  
![ASTC 6x6](https://github.com/richgel999/junkdrawer/blob/main/aft_lounge_4k_astc_6x6_exp_3_0.png)

[BC6H](https://github.com/richgel999/junkdrawer/blob/main/aft_lounge_4k_bc6h_exp_3_0.png):  
![BC6H](https://github.com/richgel999/junkdrawer/blob/main/aft_lounge_4k_bc6h_exp_3_0.png)

- xmen.png (LDR, no tonemapping), 1000x1482, 2.99 bits/pixel, 11ms decode to ASTC, 51.5ms transcode to BC6H

[ASTC HDR 6x6](https://github.com/user-attachments/assets/54b764c7-d90f-4ff1-a76a-a90530cb5577)  
![image](https://github.com/user-attachments/assets/54b764c7-d90f-4ff1-a76a-a90530cb5577)

[BC6H](https://github.com/user-attachments/assets/49d8245c-a625-41a4-a269-41f770f66575)  
![image](https://github.com/user-attachments/assets/49d8245c-a625-41a4-a269-41f770f66575)

- batman_cover.png (LDR, no tonemapping), 3.1 bits/pixel, 1.5ms decode to ASTC, 12.3ms transcode to BC6H

[ASTC HDR 6x6](https://github.com/user-attachments/assets/5178a660-f49d-4fa6-8e23-3c90f0639943)  
![image](https://github.com/user-attachments/assets/5178a660-f49d-4fa6-8e23-3c90f0639943)

[BC6H](https://github.com/user-attachments/assets/0ba5dae5-38ae-4912-a2bc-2f6c1c0126b3)  
![image](https://github.com/user-attachments/assets/0ba5dae5-38ae-4912-a2bc-2f6c1c0126b3)

- sciwallpaper.png (LDR, no tonemapping), 2880x1800, 2.59 bits/pixel, 35.5ms decode to ASTC, 202ms transcode to BC6H

[ASTC HDR 6x6](https://github.com/user-attachments/assets/0117a1b5-db72-4bb9-ba08-24dea0d9e59b)
![image](https://github.com/user-attachments/assets/0117a1b5-db72-4bb9-ba08-24dea0d9e59b)

[BC6H](https://github.com/user-attachments/assets/be88a776-654b-4c6e-92db-a0ff1388f1ee)
![image](https://github.com/user-attachments/assets/be88a776-654b-4c6e-92db-a0ff1388f1ee)

- desk.exr, 644x874, 3.1 bits/pixel, 7.6ms decode to ASTC, 26.5ms transcode to BC6H

[ASTC HDR 6x6](https://github.com/user-attachments/assets/db2da419-b475-4e18-b4f7-179534369852)  
![image](https://github.com/user-attachments/assets/db2da419-b475-4e18-b4f7-179534369852)

[BC6H](https://github.com/user-attachments/assets/4ea2eca7-4391-4c0a-b322-d46965d1e35c)  
![image](https://github.com/user-attachments/assets/4ea2eca7-4391-4c0a-b322-d46965d1e35c)

LDR delta visualization (tonemapped ASTC HDR 6x6 - tonemapped BC6H, biased by 128):  
![image](https://github.com/user-attachments/assets/58a32c63-e217-4550-a3cd-15d7507bb4e3)

- Custom Processing/visualization tool screenshot:

![image](https://github.com/user-attachments/assets/b7c749d4-845b-49d3-9f95-5de88f10b9be)


