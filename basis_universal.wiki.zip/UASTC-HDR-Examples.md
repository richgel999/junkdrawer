Here are some example .HDR/.EXR images compressed to [UASTC HDR (8 bits/texel)](https://github.com/BinomialLLC/basis_universal/wiki/UASTC-HDR-Texture-Specification-v1.0) Khronos [.KTX2 files](https://registry.khronos.org/KTX/specs/2.0/ktxspec.v2.html). Many were compressed using the encoder's default options (UASTC HDR level 1). The .KTX2 files were then transcoded to BC6H (no transcoding is needed to ASTC HDR, because UASTC HDR is standard ASTC HDR data), then the ASTC HDR and BC6H textures were uncompressed to half-float .EXR using software decoders. 

These half-float HDR images were then [Reinhard tonemapped](https://en.wikipedia.org/wiki/Tone_mapping) at various exposures for easy display on standard webpages and saved to 24-bit .PNG's. The Reinhard global tonemap function was individually applied to each RGB channel. The tonemapped result was converted to sRGB 8-bits with plain rounding (no dithering).

Compression timings are from an ASUS Zenbook 14X, Raptor Lake, Core i7 13700H. Quality statistics are HDR FP16 avg. RGB (i.e. standard RGB average PSNR's, with the decoded output half-float bits interpreted as unsigned int16_t's) -- higher is better.

Command line:

```
basisu -stats image.exr
basisu image.ktx2
basisu -tonemap image_hdr_unpacked_rgb_BC6H_face_0_layer_0000.exr
basisu -tonemap image_hdr_unpacked_rgb_ASTC_HDR_RGBA_face_0_layer_0000.exr
```

## BarHarborSunrise.exr (resampled by .75 with a box filter for GitHub, before compression), UASTC Level 3

```
Dimensions: 3216x1809
Compression time: 26.018 seconds
ASTC PSNR: 54.267570 dB
BC6H PSNR: 54.253075 dB
```

Note: Level 1 compression time is 4.123 seconds, and level 0 is 2.188 seconds.

Tonemap exposure scale: x0.25

- ASTC HDR:  
![image](https://github.com/user-attachments/assets/a28e4318-dc87-4972-8e75-8fae076fdbaa)

- BC6H:  
![image](https://github.com/user-attachments/assets/05d2f61f-8ced-4a0e-bfb3-300cc049dd2a)

Tonemap exposure scale: x1

- ASTC HDR:  
![image](https://github.com/user-attachments/assets/c4d05efc-e8af-4a56-b48a-0e609c85f5b9)

- BC6H:  
![image](https://github.com/user-attachments/assets/ae1c25a8-c7d4-41ab-b802-67042629a1be)

Tonemap exposure scale: x8

- ASTC HDR:  
![image](https://github.com/user-attachments/assets/c3adb249-7eb8-486d-a943-4a4f40a78ca5)

- BC6H:  
![image](https://github.com/user-attachments/assets/f64ef74c-5776-4696-8211-16c2518a8cd7)

## Desk.exr, UASTC HDR Level 1

```
Dimensions: 644x874
Compression time: .371 seconds
ASTC: PSNR: 50.539391 dB
BC6H: PSNR: 50.529366 dB
```

Tonemap exposure scale: x1

- ASTC HDR:  
![image](https://github.com/user-attachments/assets/b96fb10d-2cf8-4e7f-95aa-04a8476be4f8)

- BC6H:  
![image](https://github.com/user-attachments/assets/9d55fc08-75c1-42e5-a704-08364fd0e1a9)

## Desk.exr, UASTC HDR Level 4, -hdr_uber_mode

```
Dimensions: 644x874
Compression time: 20.647 seconds
ASTC: PSNR: 51.254608 dB
BC6H: PSNR: 51.234970 dB
```

Tonemap exposure scale: x1

- ASTC HDR:  
![image](https://github.com/user-attachments/assets/45457900-b482-4b8c-a33c-eaeefb50bc19)

- BC6H:  
![image](https://github.com/user-attachments/assets/4dee1ce9-f942-48e4-bb4f-7df3bba3b503)


## CandleGlass.exr, UASTC HDR Level 1

```
Dimensions: 1000x810
Compression time: 1.989 seconds
ASTC: PSNR: 60.459099 dB
BC6H: PSNR: 60.397514 dB
```

Tonemap exposure scale: x0.0625

- ASTC HDR:  
![image](https://github.com/user-attachments/assets/547c8728-0a1d-440d-91fe-2fe759abe831)

- BC6H:  
![image](https://github.com/user-attachments/assets/622b0d25-d0bb-42ea-9aed-0f337b82441d)

Tonemap exposure scale: x4

- ASTC HDR:  
![image](https://github.com/user-attachments/assets/6a9a5baa-b419-4c72-9e48-14f059f8235f)

- BC6H:  
![image](https://github.com/user-attachments/assets/ece1a332-1392-4e20-8d6c-f4f571db24be)

Tonemap exposure scale: x32

- ASTC HDR:  
![image](https://github.com/user-attachments/assets/c475b98a-914a-4642-bde8-201d412f68c1)

- BC6H:  
![image](https://github.com/user-attachments/assets/9dc70ad0-d0bc-4ad7-890f-01b6068e9a83)

## office.hdr, UASTC HDR Level 1

```
Dimensions: 2000x1312
Compression time: 1.777 seconds
ASTC PSNR: 60.984371 dB
BC6H PSNR: 60.851002 dB
UASTC HDR Level 1
```

Tonemap exposure scale: x4

- ASTC HDR:  
![image](https://github.com/user-attachments/assets/b41e396a-7315-4bc9-a2e4-614bb2a233fd)

- BC6H:  
![image](https://github.com/user-attachments/assets/c887d2c9-4fa6-401f-ba0e-77b46fcd7187)

## yucca.exr, UASTC HDR Level 1

```
Dimensions: 1296x972
Compression time: .765 seconds
ASTC PSNR: 53.553314 dB
BC6H PSNR: 53.533680 dB
```

Tonemap exposure scale: x1

- ASTC HDR:  
![image](https://github.com/user-attachments/assets/99102f23-afc8-49de-b5a9-7540ea7cf253)

- BC6H:  
![image](https://github.com/user-attachments/assets/6e75757f-7cb1-4484-b055-c717f1752387)

## memorial.exr, UASTC HDR Level 1

```
Dimensions: 512x768
Compression time: .235 seconds
ASTC PSNR: 53.896767 dB
BC6H PSNR: 53.877651 dB
UASTC HDR Level 1
```

Tonemap exposure scale: x0.125

- ASTC HDR:  
![image](https://github.com/user-attachments/assets/01b238f9-9d2c-4023-aa49-dff3a49fe017)

- BC6H:  
![image](https://github.com/user-attachments/assets/afac7955-9861-4d6a-9ed5-a97630fc6b42)

Tonemap exposure scale: x4

- ASTC HDR:  
![image](https://github.com/user-attachments/assets/b09ab913-f223-48e0-b502-57458a6fb368)

- BC6H:  
![image](https://github.com/user-attachments/assets/3160ee0a-239f-4e6b-b67e-5d01353a16bd)

## MtTamWest.exr, UASTC HDR Level 3

```
Dimensions: 1214x732
Compression time: 3.163 seconds
ASTC PSNR: 54.267570 dB
BC6H PSNR: 54.253075 dB
```

Tonemap exposure scale: x4

- ASTC HDR:  
![image](https://github.com/user-attachments/assets/6ae95477-3621-47b9-8957-d8a2553392fd)

- BC6H:  
![image](https://github.com/user-attachments/assets/7bde338d-8aa3-4e13-96b0-0d566d194172)

Tonemap exposure scale: x16

- ASTC HDR:  
![image](https://github.com/user-attachments/assets/bbdda5bb-2c36-43fd-9235-4a7fe5404800)

- BC6H:  
![image](https://github.com/user-attachments/assets/d564e675-7f17-43f8-a872-5a9529780a17)

